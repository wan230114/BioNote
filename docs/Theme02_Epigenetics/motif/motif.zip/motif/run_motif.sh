#!/usr/bin/env bash
#############################################
# @ Author: Chen Jun
# @ Author Email: 1170101471@qq.com
# @ Created Date: 2020-11-18, 00:34:14
# @ Modified By: Chen Jun
# @ Last Modified: 2020-11-24, 08:52:26
#############################################

export PATH=/home/gzsc/biotools/HOMER/bin/:$PATH


inbed=$1  # in.bed
outdir=`if [ "$2" ]; then echo motif_$2; else echo motif; fi`
ref=hg38
ref=`if [ "$3" ]; then echo $3; else echo hg38; fi`

echo args: $inbed $outdir $ref

findMotifsGenome.pl $inbed $ref $outdir -len 8,10,12
