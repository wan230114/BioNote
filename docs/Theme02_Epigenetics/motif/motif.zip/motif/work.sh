Name="out"
Bed="./test.bed"
Genome="./genome.fa"

cp /home/chenjun/pipeline/chip/v1.3.4/script/R_work/motif/run_motif.sh .

echo sh run_motif.sh $Bed $Name $Genome
sh run_motif.sh $Bed $Name $Genome &>log_motif.$Name.txt

cat genome.fa| grep CAGAGGAA  -B 5
